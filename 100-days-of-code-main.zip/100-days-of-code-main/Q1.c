// 1st day of #100 days code 
// Question 1 : Write a program to input two numbers and display their sum.
#include <stdio.h>
int main(){
    int a, b , sum ;
    scanf("%d %d", &a, &b);
    sum = a + b;
    printf("Sum: %d\n", sum);
    return 0;
}